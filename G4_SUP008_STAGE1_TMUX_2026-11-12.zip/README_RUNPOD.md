# G4 SUP-008 — Stage 1 only, with mandatory first-IID hold

**Authority:** Master's 12 Nov 2026 conditional GO. This operational package is **not** a change to the thesis repository; keep it at `/workspace/sup008_stage1/` (outside the repo). It must not overwrite any existing `outputs/sup008` directory.

## 1. Stage files on RunPod

Upload `G4_SUP008_STAGE1_TMUX_2026-11-12.zip` through the RunPod file interface to `/workspace/`. On RunPod:

```bash
cd /workspace && mkdir -p sup008_stage1 && unzip -n G4_SUP008_STAGE1_TMUX_2026-11-12.zip -d sup008_stage1
chmod +x /workspace/sup008_stage1/launch_stage1.sh
```

The ZIP contains three files directly at its root. Never extract the operational package over `src/` or `configs/`.

## 2. Read-only preflight (outside tmux)

```bash
cd /workspace/thesis-fl-xai
python /workspace/sup008_stage1/sup008_stage1_gate.py preflight
```

A PASS checks: clean exact Git revision `20969563229de10f4d65f1172c3389e0b86b169c`, 15,000 canonical image IDs with cache and DICOM paths, original split fingerprints, all six YAMLs and protocol invariants, zero competing compute PIDs, at least 30 GiB free, and absence of an existing `outputs/sup008` tree. Do not proceed on any failure; report it to G4.

## 3. Start in tmux

```bash
cd /workspace/thesis-fl-xai
tmux new -s sup008_stage1
```

Inside tmux:

```bash
bash /workspace/sup008_stage1/launch_stage1.sh
```

Detach using **Ctrl+B**, then **D**. Reattach with `tmux attach -t sup008_stage1`. The script runs **only** centralized seed 2026, centralized seed 31415, and IID seed 2026. It stops on errors, runs the Round-50 prediction exporter after IID, performs independent structured audit checks, records checksums/logs/provenance, then **always stops at the mandatory HOLD**. Do not launch the old all-six reference script.

The entire run will occupy one GPU, but only one training experiment at a time. Do not start competing GPU workloads.

## 4. First-IID hold evidence

If the script prints `STAGE 1 DONE. MANDATORY HOLD`, share the following **small** records with G4:

- `outputs/sup008/logs/g4_sup008_iid_seed2026_hold_audit.log`
- `outputs/sup008/logs/g4_sup008_iid_seed2026_export.log`
- `outputs/sup008/sup008_evidence/g4_sup008_iid_seed2026/g4_sup008_iid_seed2026_R50_metrics.json`
- `outputs/sup008/checkpoints/g4_sup008_iid_seed2026/sup008_fit_participation.jsonl`
- `outputs/sup008/provenance/environment_at_launch.txt`
- `outputs/sup008/provenance/sha256_at_launch.txt`
- `outputs/sup008/provenance/first_iid_hold_sha256.txt`

No checkpoint `.pt` files or 3,000-prediction CSV uploads are needed initially. If a failure occurs, share the corresponding error/QA log and do **not** relaunch with overwritten output directories.

The G4 specialist reviews the hold evidence before Stage 2 (IID seed 31415, non-IID seeds 2026 and 31415) is scheduled. The Master allows Stage 2 only after a PASS of the first-IID hold point.

**Key caveat:** New runs are protocol-matched on the documented current commit; historical byte-for-byte code identity remains unverified. SUP-009 is not closed; no Grad-CAM or unrelated conditions are authorized.
